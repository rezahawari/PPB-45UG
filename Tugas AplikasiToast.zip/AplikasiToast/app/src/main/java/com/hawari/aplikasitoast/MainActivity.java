package com.hawari.aplikasitoast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView angka;
    int tampung = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        angka=findViewById(R.id.textCount);
    }

    public void Counting(View view) {
        tampung = tampung+1;
        angka.setText(Integer.toString(tampung));
    }

    public void klikToast(View view) {
        tampung = 0;
        angka.setText("0");
        Toast.makeText(this, "Angka Berhasil di Reset", Toast.LENGTH_LONG).show();
    }
}