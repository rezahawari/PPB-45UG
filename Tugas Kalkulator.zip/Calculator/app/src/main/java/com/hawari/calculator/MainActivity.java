package com.hawari.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView viewCal;
    TextView preview;
    String operasi;
    String tampung;
    Integer bil1;
    Integer bil2;
    Integer hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewCal = findViewById(R.id.viewCal);
        preview = findViewById(R.id.preview);
        viewCal.setText("0");
    }


    public void klikAC(View view) {
        bil1 = null;
        bil2 = null;
        operasi = null;
        hasil = null;
        preview.setText("");
        viewCal.setText("0");
    }

    public void klikC(View view) {
        viewCal.setText("0");
    }

    public void klikKosong(View view) {
        Toast.makeText(this, "Ini Hanya Tombol Kosong", Toast.LENGTH_LONG).show();
    }

    public void klikBagi(View view) {
        operasi = ":";
        if(bil1 == null){
            bil1 = Integer.parseInt((String) viewCal.getText());
            preview.setText(bil1 + " " + operasi);
            viewCal.setText("0");
        }else{
            if(hasil == null){
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }else{
                bil1 = hasil;
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }
        }
    }

    public void klik7(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("7");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "7");
        }
    }

    public void klik8(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("8");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "8");
        }
    }

    public void klik9(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("9");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "9");
        }
    }

    public void klikKali(View view) {
        operasi = "x";
        if(bil1 == null){
            bil1 = Integer.parseInt((String) viewCal.getText());
            preview.setText(bil1 + " " + operasi);
            viewCal.setText("0");
        }else{
            if(hasil == null){
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }else{
                bil1 = hasil;
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }
        }
    }

    public void klik4(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("4");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "4");
        }
    }

    public void klik5(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("5");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "5");
        }
    }

    public void klik6(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("6");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "6");
        }
    }

    public void klikMinus(View view) {
        operasi = "-";
        if(bil1 == null){
            bil1 = Integer.parseInt((String) viewCal.getText());
            preview.setText(bil1 + " " + operasi);
            viewCal.setText("0");
        }else{
            if(hasil == null){
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }else{
                bil1 = hasil;
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }
        }
    }

    public void klik1(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("1");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "1");
        }
    }

    public void klik2(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("2");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "2");
        }
    }

    public void klik3(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("3");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "3");
        }
    }

    public void klikPlus(View view) {
        operasi = "+";
        if(bil1 == null){
            bil1 = Integer.parseInt((String) viewCal.getText());
            preview.setText(bil1 + " " + operasi);
            viewCal.setText("0");
        }else{
            if(hasil == null){
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }else{
                bil1 = hasil;
                bil2 = Integer.parseInt((String) viewCal.getText());
                if(operasi == "+"){
                    hasil = bil1 + bil2;
                }else if(operasi == "-"){
                    hasil = bil1 - bil2;
                }else if(operasi == "x"){
                    hasil = bil1 * bil2;
                }else if(operasi == ":"){
                    hasil = bil1 / bil2;
                }
                preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
                viewCal.setText("0");
            }
        }
    }

    public void klik0(View view) {
        if(viewCal.getText() == "0"){
            viewCal.setText("0");
        }else{
            tampung = (String) viewCal.getText();
            viewCal.setText(tampung + "0");
        }
    }

    public void klikHasil(View view) {
        bil2 = Integer.parseInt((String) viewCal.getText());
        if(operasi == "+"){
            hasil = bil1 + bil2;
        }else if(operasi == "-"){
            hasil = bil1 - bil2;
        }else if(operasi == "x"){
            hasil = bil1 * bil2;
        }else if(operasi == ":"){
            hasil = bil1 / bil2;
        }
        preview.setText(bil1 + " " + operasi + " " + bil2 + " = " + hasil);
        viewCal.setText("0");
    }
}