package com.hawari.appmenu;

import java.io.OptionalDataException;
import java.util.ArrayList;
import java.util.Set;

public class Data {
    private static String[] isi = {"Nasi Goreng", "Mie Goreng", "Ayam Goreng"};
    private static String[] hrg = {"10000","15000","17000"};
    private static int[] gbr = {
            R.drawable.nasgor, R.drawable.mie , R.drawable.ayam
    };
    private static String[] desc = {
            "Nasi Goreng adalah nasi yang di goreng dengan bumbu yang istimewa",
            "Mie Goreng adalah mie yang di goreng dengan cita rasa yang sangat lezat",
            "Ayam Goreng adalah ayam yang di goreng dengan bumbu khas indonesia"
    };

    static ArrayList<SetData> getListData(){
        ArrayList<SetData> list = new ArrayList<>();
        for (int i = 0 ; i < isi.length ; i++){
            SetData set = new SetData();
            set.setNama(isi[i]);
            set.setHarga(hrg[i]);
            set.setImg(gbr[i]);
            set.setDesc(desc[i]);
            list.add(set);
        }
        return list;
    }
}
