package com.hawari.appmenu;

public class SetMinum {
    private String menuMinum;
    private String hrgMinum;
    private String descMinum;
    private int gbrMinum;

    public String getMenuMinum() {
        return menuMinum;
    }

    public void setMenuMinum(String menuMinum) {
        this.menuMinum = menuMinum;
    }

    public String getHrgMinum() {
        return hrgMinum;
    }

    public void setHrgMinum(String hrgMinum) {
        this.hrgMinum = hrgMinum;
    }

    public String getDescMinum() {
        return descMinum;
    }

    public void setDescMinum(String descMinum) {
        this.descMinum = descMinum;
    }

    public int getGbrMinum() {
        return gbrMinum;
    }

    public void setGbrMinum(int gbrMinum) {
        this.gbrMinum = gbrMinum;
    }
}
