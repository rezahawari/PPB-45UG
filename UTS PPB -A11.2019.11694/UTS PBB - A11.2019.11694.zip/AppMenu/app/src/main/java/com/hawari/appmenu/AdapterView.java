package com.hawari.appmenu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class AdapterView extends RecyclerView.Adapter<AdapterView.ViewHolder> {
    private ArrayList<SetData> set;
    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }

    public AdapterView(ArrayList<SetData> list){
        this.set = list;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.isi_lis,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SetData setdata = set.get(position);
        Glide.with(holder.itemView.getContext())
                .load(setdata.getImg())
                .apply(new RequestOptions().override(55,55))
                .into(holder.img);
        holder.txt1.setText(setdata.getNama());
        holder.txt2.setText("Rp "+setdata.getHarga());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemCLickedF(set.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return set.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView txt1,txt2;
        ViewHolder(View view) {
            super(view);
            img = view.findViewById(R.id.imgList);
            txt1 = view.findViewById(R.id.namaMenu);
            txt2 = view.findViewById(R.id.hrgMenu);
        }
    }

    public interface OnItemClickCallback{
        void onItemCLickedF(SetData data);
    }
}
