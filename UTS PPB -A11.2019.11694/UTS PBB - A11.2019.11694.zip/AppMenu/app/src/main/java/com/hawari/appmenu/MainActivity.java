package com.hawari.appmenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    protected ListAdapter adapter;
    Database database;
    protected Cursor cursor;
    public static MainActivity ma;
    TextView txtCart;
    RecyclerView rcView;
    ArrayList<SetData> set = new ArrayList<>();
    RecyclerView mnView;
    ArrayList<SetMinum> mnm = new ArrayList<>();
    SimpleAdapter Adapter, adap;
    HashMap<String, String> map, maping;
    ArrayList<HashMap<String, String>> mylist, urlist;
    ListView inilis, minum;
    String[] hitung;
    String[] isi = {"Nasi Goreng", "Mie Goreng", "Ayam Goreng"};
    String[] hrg = {"10000","15000","17000"};
    String[] desc = {
            "Nasi Goreng adalah nasi yang di goreng dengan bumbu yang istimewa",
            "Mie Goreng adalah mie yang di goreng dengan cita rasa yang sangat lezat",
            "Ayam Goreng adalah ayam yang di goreng dengan bumbu khas indonesia"
    };
    String[] gbr = {
            Integer.toString(R.drawable.nasgor), Integer.toString(R.drawable.mie) , Integer.toString(R.drawable.ayam)
    };
    String[] menuMinum = {"Es Teh", "Es Jeruk", "Kopi Susu"};
    String[] hrgMinum = {"2000", "3000", "5000"};
    String[] descMinum = {
            "Es teh adalah minuman teh yang disajikan dengan es batu",
            "Es jeruk adalah minuman segar yang tebuat dari jeruk peras",
            "Kopi Susu adalah minuman berbahan dasar espresso dan dicampur susu"
    };
    String[] gbrMinum = {
            Integer.toString(R.drawable.esteh), Integer.toString(R.drawable.esjeruk), Integer.toString(R.drawable.kopsu)
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ma = this;
        rcView = findViewById(R.id.lis);
        set.addAll(Data.getListData());
        mnView = findViewById(R.id.lisMinum);
        mnm.addAll(Minum.getListData());
//        mnView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i
//            }
//        });
//        ListView inilis = findViewById(R.id.lis);
        txtCart = findViewById(R.id.jmlCart);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,CartActivity.class);
                startActivity(i);
            }
        });
        database = new Database(this);
//        ListView minum = findViewById(R.id.lisMinum);
        mylist = new ArrayList<HashMap<String,String>>();
        for (int i = 0; i < isi.length; i++){
            map = new HashMap<String, String>();
            map.put("isi", isi[i]);
            map.put("harga", "Rp "+hrg[i]);
            map.put("gambar", gbr[i]);
            mylist.add(map);
        }
//        Adapter = new SimpleAdapter(this,mylist,R.layout.isi_lis,new String[] {"isi","harga","gambar"},new int[] {R.id.namaMenu, R.id.hrgMenu, R.id.imgList});
//        inilis.setAdapter(Adapter);
//        inilis.setSelected(true);
//        inilis.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//               final String selection = isi[position];
//               Bundle bundle = new Bundle();
//               bundle.putString("nama", selection);
//               bundle.putString("harga", hrg[position]);
//               bundle.putString("desc", desc[position]);
//               bundle.putString("img", gbr[position]);
//               Intent i = new Intent(MainActivity.this,DetailActivity.class);
//               i.putExtras(bundle);
//               startActivity(i);
//            }
//        });

//        urlist = new ArrayList<HashMap<String,String>>();
//        for (int i = 0 ; i < menuMinum.length ; i++){
//            maping = new HashMap<String,String>();
//            maping.put("menuMinum", menuMinum[i]);
//            maping.put("hrgMinum", "Rp " +hrgMinum[i]);
//            maping.put("imgMinum", gbrMinum[i]);
//            urlist.add(maping);
//        }
//        adap = new SimpleAdapter(this,urlist,R.layout.isi_lis,new String[] {"menuMinum", "hrgMinum", "imgMinum"}, new int[] {R.id.namaMenu, R.id.hrgMenu, R.id.imgList});
//        minum.setAdapter(adap);
//        minum.setSelected(true);
//        minum.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Bundle bandel = new Bundle();
//                bandel.putString("nama", menuMinum[position]);
//                bandel.putString("harga", hrgMinum[position]);
//                bandel.putString("desc", descMinum[position]);
//                bandel.putString("img", gbrMinum[position]);
//                Intent u = new Intent(MainActivity.this,DetailActivity.class);
//                u.putExtras(bandel);
//                startActivity(u);
//            }
//        });
        showView();
        showMinum();
        Refresh();

    }

    private void showView(){
        rcView.setLayoutManager(new LinearLayoutManager(this));
        com.hawari.appmenu.AdapterView adp = new com.hawari.appmenu.AdapterView(set);
        rcView.setAdapter(adp);

        adp.setOnItemClickCallback(new com.hawari.appmenu.AdapterView.OnItemClickCallback() {
            @Override
            public void onItemCLickedF(SetData data) {
                showSelectedData(data);
            }
        });
    }

    private void showMinum(){
        mnView.setLayoutManager(new LinearLayoutManager(this));
        AdapterMinum adpter = new AdapterMinum(mnm);
        mnView.setAdapter(adpter);

        adpter.setOnItemClickCallbackM(new AdapterMinum.OnItemClickCallbackM() {
            @Override
            public void onItemCLickedM(SetMinum data) {
                showSelectedMinum(data);
            }
        });
    }

    public void Refresh(){
        SQLiteDatabase dbase = database.getReadableDatabase();
        cursor = dbase.rawQuery("SELECT * FROM cart",null);
        hitung = new String[cursor.getCount()];
        cursor.moveToFirst();
        int jml = 0;
        for (int i = 0 ; i < cursor.getCount() ; i++){
            cursor.moveToPosition(i);
            hitung[i] = cursor.getString(1).toString();
        }

        txtCart.setText(String.valueOf(hitung.length));
    }

    private void showSelectedData(SetData data){
        Bundle bundle = new Bundle();
        bundle.putString("nama", data.getNama());
        bundle.putString("harga", data.getHarga());
        bundle.putString("desc", data.getDesc());
        bundle.putString("img", String.valueOf(data.getImg()));
        Intent i = new Intent(MainActivity.this,DetailActivity.class);
        i.putExtras(bundle);
        startActivity(i);
    }

    private void showSelectedMinum(SetMinum data){
        Bundle bandel = new Bundle();
        bandel.putString("nama", data.getMenuMinum());
        bandel.putString("harga", data.getHrgMinum());
        bandel.putString("desc", data.getDescMinum());
        bandel.putString("img", String.valueOf(data.getGbrMinum()));
        Intent u = new Intent(MainActivity.this,DetailActivity.class);
        u.putExtras(bandel);
        startActivity(u);
    }
}