package com.hawari.appmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {
    protected Cursor cursor;
    ImageView imgDetail;
    TextView txt,dsc,prc;
    String param;
    Button btn;
    Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        imgDetail = findViewById(R.id.imgView);
        Bundle bundle = getIntent().getExtras();
        database = new Database(this);
        txt = findViewById(R.id.titleTxt);
        dsc = findViewById(R.id.descTxt);
        prc = findViewById(R.id.price);
        btn = findViewById(R.id.btnCart);
        txt.setText(bundle.getString("nama"));
        dsc.setText(bundle.getString("desc"));
        prc.setText(bundle.getString("harga"));
        imgDetail.setImageResource(Integer.parseInt(bundle.getString("img")));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = database.getWritableDatabase();
                String sql = "INSERT INTO cart(nama,harga,qty) VALUES('"+ txt.getText().toString() +"','"+ prc.getText().toString() +"','1')";
                db.execSQL(sql);
                Toast.makeText(DetailActivity.this, "Berhasil Menambahkan Keranjang", Toast.LENGTH_SHORT).show();
                MainActivity.ma.Refresh();
                finish();
            }
        });
    }
}