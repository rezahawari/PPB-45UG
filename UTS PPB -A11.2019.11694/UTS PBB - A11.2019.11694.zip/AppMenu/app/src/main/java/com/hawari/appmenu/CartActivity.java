package com.hawari.appmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentUris;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class CartActivity extends AppCompatActivity {
    Database database;
    String[] hrg;
    String[] qty;
    String[] img;
    String[] data;
    ListView liscart;
    TextView crt,total;
    Button clear;
    int Tot;
    protected Cursor cursor;
    SimpleAdapter adapter;
    HashMap<String,String> map;
    ArrayList<HashMap<String,String>> mylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        liscart = findViewById(R.id.lisCart);
        crt = findViewById(R.id.textCart);
        total = findViewById(R.id.txtTotal);
        clear = findViewById(R.id.btnClear);
        database = new Database(this);
        mylist = new ArrayList<HashMap<String,String>>();
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase dbase = database.getWritableDatabase();
                String sql = "DELETE FROM cart";
                dbase.execSQL(sql);
                Toast.makeText(CartActivity.this, "Cart Berhasil Dihapus", Toast.LENGTH_SHORT).show();
                MainActivity.ma.Refresh();
                finish();
            }
        });
        RefreshList();
    }
    public void RefreshList(){
        SQLiteDatabase db = database.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM cart",null);
        data = new String[cursor.getCount()];
        hrg = new String[cursor.getCount()];
        img = new String[cursor.getCount()];
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++){
            cursor.moveToPosition(i);
            data[i] = cursor.getString(1).toString();
            hrg[i] = cursor.getString(2).toString();
            Tot += Integer.parseInt(cursor.getString(2));
            if (cursor.getString(1).toString() == "Nasi Goreng"){
                img[i] = Integer.toString(R.drawable.nasgor);
            }else if(cursor.getString(1).toString() == "Mie Goreng"){
                img[i] = Integer.toString(R.drawable.mie);
            }else if(cursor.getString(1).toString() == "Ayam Goreng"){
                img[i] = Integer.toString(R.drawable.ayam);
            }else if(cursor.getString(1).toString() == "Es Teh"){
                img[i] = Integer.toString(R.drawable.esteh);
            }else if(cursor.getString(1).toString() == "Es Jeruk"){
                img[i] = Integer.toString(R.drawable.esjeruk);
            }else if(cursor.getString(1).toString() == "Kopi Susu"){
                img[i] = Integer.toString(R.drawable.kopsu);
            }
        }

        int nomor = 0;
        for(int i = 0 ; i < data.length ; i++){
            map = new HashMap<String,String>();
            map.put("isi", data[i]);
            map.put("harga","Rp "+hrg[i]);
            map.put("gambar", img[i]);
//            if (data[i].toString() == "Nasi Goreng"){
//                map.put("gambar", Integer.toString(R.drawable.nasgor));
//            }else if(data[i].toString() == "Mie Goreng"){
//                map.put("gambar", Integer.toString(R.drawable.mie));
//            }else if(data[i].toString() == "Ayam Goreng"){
//                map.put("gambar", Integer.toString(R.drawable.ayam));
//            }else if(data[i].toString() == "Es Teh"){
//                map.put("gambar", Integer.toString(R.drawable.esteh));
//            }else if(data[i].toString() == "Es Jeruk"){
//                map.put("gambar", Integer.toString(R.drawable.esjeruk));
//            }else if(data[i].toString() == "Kopi Susu"){
//                map.put("gambar", Integer.toString(R.drawable.kopsu));
//            }

            mylist.add(map);
            nomor += 1;
        }

        adapter = new SimpleAdapter(this,mylist,R.layout.isi_lis,new String[] {"isi","harga","gambar"},new int[] {R.id.namaMenu, R.id.hrgMenu,R.id.imgList});
        liscart.setAdapter(adapter);
        liscart.setSelected(false);

        crt.setText("CART ("+nomor+")");
        total.setText("TOTAL : Rp "+Tot);
//        liscart.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, data));
//        liscart.setSelected(true);

    }
}