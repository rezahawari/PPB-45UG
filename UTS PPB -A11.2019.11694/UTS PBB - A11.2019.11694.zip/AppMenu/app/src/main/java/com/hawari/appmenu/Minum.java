package com.hawari.appmenu;

import java.util.ArrayList;

public class Minum {
    private static String[] menuMinum = {"Es Teh", "Es Jeruk", "Kopi Susu"};
    private static String[] hrgMinum = {"2000", "3000", "5000"};
    private static String[] descMinum = {
            "Es teh adalah minuman teh yang disajikan dengan es batu",
            "Es jeruk adalah minuman segar yang tebuat dari jeruk peras",
            "Kopi Susu adalah minuman berbahan dasar espresso dan dicampur susu"
    };
    private static int[] gbrMinum = {
            R.drawable.esteh, R.drawable.esjeruk, R.drawable.kopsu
    };

    static ArrayList<SetMinum> getListData(){
        ArrayList<SetMinum> list = new ArrayList<>();
        for (int i = 0 ; i < menuMinum.length ; i++){
            SetMinum set = new SetMinum();
            set.setMenuMinum(menuMinum[i]);
            set.setHrgMinum(hrgMinum[i]);
            set.setGbrMinum(gbrMinum[i]);
            set.setDescMinum(descMinum[i]);
            list.add(set);
        }
        return list;
    }
}
