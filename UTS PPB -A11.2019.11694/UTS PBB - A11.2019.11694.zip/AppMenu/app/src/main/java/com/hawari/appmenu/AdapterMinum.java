package com.hawari.appmenu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class AdapterMinum extends RecyclerView.Adapter<AdapterMinum.ViewHolderM> {
    private ArrayList<SetMinum> set;
    private OnItemClickCallbackM click;

    public void setOnItemClickCallbackM(AdapterMinum.OnItemClickCallbackM onItemClickCallbackM){
        this.click = onItemClickCallbackM;
    }

    public AdapterMinum(ArrayList<SetMinum> list){
        this.set = list;
    }
    @NonNull
    @Override
    public AdapterMinum.ViewHolderM onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.isi_lis,parent,false);
        return new AdapterMinum.ViewHolderM(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMinum.ViewHolderM holder, int position) {
        SetMinum setMinum = set.get(position);
        Glide.with(holder.itemView.getContext())
                .load(setMinum.getGbrMinum())
                .apply(new RequestOptions().override(55,55))
                .into(holder.img);
        holder.txt1.setText(setMinum.getMenuMinum());
        holder.txt2.setText("Rp "+setMinum.getHrgMinum());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click.onItemCLickedM(set.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return set.size();
    }

    public class ViewHolderM extends RecyclerView.ViewHolder{
        ImageView img;
        TextView txt1,txt2;

        public ViewHolderM(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.imgList);
            txt1 = itemView.findViewById(R.id.namaMenu);
            txt2 = itemView.findViewById(R.id.hrgMenu);
        }
    }

    public interface OnItemClickCallbackM{
        void onItemCLickedM(SetMinum data);
    }
}
